﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WEEK09_01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            //SolidBrush b = new SolidBrush(Color.Lime);
            // SolidBrush b = new SolidBrush(Color.FromArgb(100, 255, 0, 0));
            //SolidBrush b = new SolidBrush(Color.FromKnownColor(KnownColor.AntiqueWhite));
            // SolidBrush b = new SolidBrush(Color.FromName("AntiqueWhite"));
            // g.FillRectangle(b, ClientRectangle);
            //  b.Dispose();

            DrawPrivateObject();
        }
        
        private void DrawPrivateObject()
        {
            Graphics g = CreateGraphics();

            SolidBrush b = new SolidBrush(Color.FromName("AntiqueWhite"));
            g.FillRectangle(b, ClientRectangle);
             b.Dispose();
        }
    }
}
